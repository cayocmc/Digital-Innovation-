### Recriando a página inicial do Instagram :iphone:

- Este projeto foi feito através do Bootcamp HTML Web Developer da Digital Innovation One e tem o intuito de treinar o conceito de CSS Flexbox e responsividade. Um conteúdo perfeito para além de treinar, aguçar a criatividade!

	###### Minha página de login:
![Instagram página inicial](https://i.imgur.com/B6DuFRN.png "Instagram página inicial" )
	
	
### 	 :computer: Tecnologias Utilizadas:

- HTML5
- CSS3
- VSC/repl.it


### Sobre a Digital Innovation One

- A [Digital Innovation One](https://digitalinnovation.one/ "Digital Innovation One") é uma comunidade que conta com mais de 200mil desenvolvedores de softwares todos com o intuito de acelerar sua carreira através de bootcamps, cursos e projetos.

![DIO](https://i.imgur.com/ZdtdimW.jpg "DIO")



Agradecimento a Digital Innovation one com a Avanade por me proporcionar mais um projeto cheio de aprendizagem.





:information_desk_person: Cayo Cezar
